package com.tms.web.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="campus")
public class Campus implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;


	

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="campus_id")
	private Integer campusId;
	
	@Column(name="campus_name")
	private String campusName;
	
	@Column(name="address")
	private String address;
	
	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Integer getCampusId() {
		return campusId;
	}

	public void setCampusId(Integer campusId) {
		this.campusId = campusId;
	}

	public String getCampusName() {
		return campusName;
	}


	public void setCampusName(String campusName) {
		this.campusName = campusName;
	}


	@Override
	public String toString() {
		return "{\"campusId\":" + campusId + ",\"campusName\":" + campusName+ ",\"address\":" + address+"}";
	}
	
	
}
