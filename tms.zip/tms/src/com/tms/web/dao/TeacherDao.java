package com.tms.web.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Property;
import org.springframework.stereotype.Repository;

 





import com.tms.web.model.Student;
import com.tms.web.model.Teacher;
@Repository
public class TeacherDao extends BaseDao<Teacher, String> {
	public Integer findId(){
		String hql = "SELECT max(teacherId) FROM Teacher";
		List<Integer> list = getSession().createQuery(hql).list();
		if(list.get(0)==null){
			return 0;
		}
		return list.get(0);
	}
	public List<Teacher> findByAccount(String accountId){
		search.addFilterEqual("accountId", accountId);
		return search(search);
	}
	public List<Teacher> findTeachers(String name,Integer campusId,Integer courseId,Character status){
		Criteria criteria = getSession().createCriteria(Teacher.class);
		if(name!=null){
			Property teacherName = Property.forName("teacherName");
			criteria.add(teacherName.eq(name));
		}
		if(campusId!=null){
			Property cpId = Property.forName("campusId");
			criteria.add(cpId.eq(campusId));
		}
		if(courseId!=null){
			Property csId = Property.forName("courseId");
			criteria.add(csId.eq(courseId));
		}
		if(status!=null){
			Property sts = Property.forName("status");
			criteria.add(sts.eq(status));
		}
		List<Teacher> teachers = criteria.list();
		System.out.println("teachers:"+teachers);
		return teachers;
	}
	
}
