package com.tms.web.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.googlecode.genericdao.search.Search;
import com.tms.web.model.Account;
import com.tms.web.model.Admin;

@Repository
public class AdminDao extends BaseDao<Admin, String> {

	public List<Admin> findById(String id){
		 
		search.addFilterEqual("adminId", id);
		return search(search);
				
	}
	
	public List<Admin> findByAccount(String accountId){
		search.addFilterEqual("accountId", accountId);
	
		return search(search); 
	}
	
	
	 
}
