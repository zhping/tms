package com.tms.web.dao;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Property;
import org.springframework.stereotype.Repository;

import com.tms.web.model.Student;
import com.tms.web.model.Study;

@Repository
public class StudyDao extends BaseDao<Study, Integer> {

	@SuppressWarnings("unchecked")
	public List<Study> findByStudy(Study study){
		Integer studentId = study.getStudentId();
		String code = study.getCode();
		Timestamp date = study.getDate();
		Integer courseId = study.getCourseId();
		
		List<Study> studys = new ArrayList<Study>();
		Criteria criteria = getSession().createCriteria(Study.class);
		if (studentId!=null) {
			Property sid = Property.forName("studentId");
			criteria.add(sid.eq(studentId));
		} 
		if (code!=null&&!code.equals("")) {
			Property c = Property.forName("code");
			criteria.add(c.eq(code));
		}
		 
		if (date!=null) {
			Property d = Property.forName("date");
			criteria.add(d.eq(date));
		}
		
		if (courseId!=null) {
			Property cid = Property.forName("courseId");
			criteria.add(cid.eq(courseId));
		} 
		studys = criteria.list();
		 
		return studys;
	}
	
	
	@SuppressWarnings("unchecked")
	public List<Study> listStudys(String code,Timestamp date,Integer courseId,Integer campusId){
		
		System.out.println("StudyDao"+date+","+courseId+","+code);
		List<Study> studys = new ArrayList<Study>();
		Criteria criteria = getSession().createCriteria(Study.class);
		
		if (code!=null&&!code.equals("")) {
			Property c = Property.forName("code");
			criteria.add(c.eq(code));
		}
		 
		if (date!=null) {
			Property d = Property.forName("date");
			criteria.add(d.eq(date));
		}
		
		if (courseId!=null) {
			Property cid = Property.forName("courseId");
			criteria.add(cid.eq(courseId));
		} 
		if (campusId!=null) {
			Property cpid = Property.forName("campusId");
			criteria.add(cpid.eq(campusId));
		}
		studys = criteria.addOrder(Order.asc("id")).list();
		return studys;
	}
	
}
