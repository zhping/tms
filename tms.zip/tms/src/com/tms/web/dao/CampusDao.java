package com.tms.web.dao;

import org.hibernate.Session;
import org.springframework.stereotype.Repository;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;

import com.tms.web.model.Campus;

@Repository
@TransactionConfiguration(transactionManager="txMgr",defaultRollback=false)
@Transactional 
public class CampusDao extends BaseDao<Campus, Integer> {

	public int updateCampus(Campus campus){
		String hql = "UPDATE Campus SET campusName=:A,address=:B WHERE　campusId＝:C";
		int n =getSession().createQuery(hql)
				.setString("A", campus.getCampusName())
				.setString("B", campus.getAddress())
				.setInteger("C", campus.getCampusId())
				.executeUpdate();
		return n;
	}
}
