package com.tms.web.dao;

import java.io.Serializable;

import org.springframework.stereotype.Repository;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;

import com.tms.web.model.Timetable;

@Repository
@TransactionConfiguration(transactionManager="txMgr",defaultRollback=false)
@Transactional 
public class TimetableDao extends BaseDao<Timetable, Integer>{
	
}
