package com.tms.web.dao;

import java.io.Serializable;

import org.springframework.stereotype.Repository;

import com.tms.web.model.Pay;

@Repository
public class PayDao extends BaseDao<Pay, Serializable>{
	
}
