package com.tms.web.dao;

import java.io.Serializable;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.googlecode.genericdao.dao.hibernate.GenericDAOImpl;
import com.googlecode.genericdao.search.Search;
import com.tms.web.model.Account;

@Repository
public class AccountDao extends BaseDao<Account, String> {

	public Boolean modifyPwd(Account account) {
		String accountId = account.getAccountId();
		String pwd =account.getPassword();
		System.out.println("dao-----------------------"+pwd);
		String hqlString="UPDATE Account SET  password=:B WHERE accountId=:A";
		int number=getSession()
				.createQuery(hqlString)
				.setString("A", accountId)
				.setString("B", pwd)
				.executeUpdate();
		System.out.println("genghaihangshu0"+number);
		if(number==1){
			return true;
		}else if (number>1) {
			return true;
		}else{
			return false;
		}
		
	}
	public List<Account> findByUsername(String username) {
		System.out.println("------------------accountdao-----------------");
		Search search = new Search();
		System.out.println("username:"+username);
		search.addFilterEqual("username", username);
		return search(search);
	}
	public Account findByUsername1(String username) {
		System.out.println("------------------accountdao-----------------");
		Search search = new Search();
		System.out.println("username:"+username);
		search.addFilterEqual("username", username);
		return (Account) search(search).get(0);
	}
	public List<Account> findAll(){
		Criteria criteria = getSession().createCriteria(Account.class);
		@SuppressWarnings("unchecked")
		List<Account> list = criteria.list();
		return list;
	}
	
	public String findIdByUser(String username){
		Search search = new Search();
		search.addFilterEqual("username", username);
		List<Account> list = search(search);
		Account account = new Account();
		System.err.println("size:"+list.size());
		if(list.size()==1){
			System.out.println("getsize");
			account = list.get(0);
			System.out.println("dao:"+account);
		}
		return account.getAccountId();
	}

}
