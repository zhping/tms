package com.tms.web.dao;

import java.io.Serializable;

import javax.persistence.Entity;

import org.springframework.stereotype.Repository;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;

import com.tms.web.model.Parent;
@Repository
@TransactionConfiguration(transactionManager="txMgr",defaultRollback=false)
@Transactional 
public class ParentDao extends BaseDao<Parent, Serializable> {

}
