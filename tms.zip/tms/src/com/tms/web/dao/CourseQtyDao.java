package com.tms.web.dao;

import java.io.Serializable;
import java.util.List;

import org.hibernate.type.AbstractBynaryType;
import org.springframework.stereotype.Repository;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;

import com.googlecode.genericdao.search.Search;
import com.tms.web.model.CourseQty;
@Repository
@Transactional 
public class CourseQtyDao extends BaseDao<CourseQty, Serializable> {
	
	public CourseQty findByStudentId(Integer studentId){
		Search search = new Search();
		search.addFilterEqual("studentId", studentId);
		List<CourseQty> qtys = search(search);
		CourseQty qty = null;
		if (qtys.size()==1) {
			qty = qtys.get(0);
		}
		return qty;
		
	}
	public int updateQty(Integer qty,Integer studentId){
		 
		String hqlString="UPDATE CourseQty SET  qty=:B WHERE studentId=:A";
		int number=getSession()
				.createQuery(hqlString)
				.setInteger("A", studentId)
				.setInteger("B", qty)
				.executeUpdate();
		return number;
		
	}
}	
