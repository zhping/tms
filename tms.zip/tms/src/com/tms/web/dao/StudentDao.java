package com.tms.web.dao;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.CriteriaUpdate;

import org.apache.taglibs.standard.lang.jstl.test.beans.PublicInterface2;
import org.hibernate.Criteria;
import org.hibernate.FetchMode;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Property;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.googlecode.genericdao.search.Search;
import com.tms.web.model.Student;

@Repository
public class StudentDao extends BaseDao<Student, Integer> {
	
	@SuppressWarnings("unchecked")
	public Integer findId(){
		String hql = "SELECT max(id) FROM Student";
		List<Integer> list = new ArrayList<Integer>();
		 
		list = getSession().createQuery(hql).list();
		System.out.println("list:"+list);
		if (list.get(0)==null) {
			return 0;
		}
		return list.get(0);
	}
	
	
	@SuppressWarnings("unchecked")
	public List<Student> findStudents(Integer campusId, Integer courseId,
			String num, String name, Integer min, Integer max) {
		Criteria criteria = getSession().createCriteria(Student.class);
		criteria.setFetchMode("course", FetchMode.JOIN)
			.setFetchMode("campus", FetchMode.JOIN)
			.createAlias("courseQty", "qty");	
		if (campusId != 0) {
			Property cpId = Property.forName("campusId");
			criteria.add(cpId.eq(campusId));
		}
		if (courseId != 0) {
			Property csId = Property.forName("courseId");
			criteria.add(csId.eq(courseId));
		}
		if (num != null && !num.equals("")) {
			Property stnum = Property.forName("num");
			criteria.add(stnum.eq(num));
		}
		if (name != null && !name.equals("")) {
			Property stname = Property.forName("name");
			criteria.add(stname.eq(name));
		}
		if(min!=null)criteria.add(Restrictions.ge("qty.qty", min));
		if(max!=null)criteria.add(Restrictions.le("qty.qty", max));
		List<Student> students = criteria.addOrder(Order.asc("id")).list();
		System.out.println("dao----" + students.size());
		return students;

	}
	
	@SuppressWarnings("unchecked")
	public Student findByNum(String num){
		System.out.println("num:"+num);
		Criteria criteria = getSession().createCriteria(Student.class);
		criteria.setFetchMode("campus", FetchMode.JOIN);
		criteria.setFetchMode("course", FetchMode.JOIN);
		
		Property stnum = Property.forName("num");
		criteria.add(stnum.eq(num));
		List<Student> list=new ArrayList<Student>();
		try {
			list = criteria.list();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		if(list.size()==1){
			System.out.println("dao----list");
			return list.get(0);
		}
		System.out.println("dao----null");
		return null;
	}
	
	public Integer getCourseIdByStudentId(Integer studentId){
		Search search = new Search();
		search.addFilterEqual("id", studentId);
		List<Student> list = search(search);
		Integer courseId = null;
		if (list.size()==1) {
			Student student = list.get(0);
			courseId =  student.getCourseId();
		}
		return courseId;
	}
	public Student findStudentById(Integer id){
		Student student = new Student();
		Criteria criteria = getSession().createCriteria(Student.class);
		criteria.setFetchMode("course", FetchMode.JOIN); 
		criteria.setFetchMode("campus", FetchMode.JOIN);
		criteria.setFetchMode("courseQty", FetchMode.JOIN);
		
		Property stid = Property.forName("id");
		criteria.add(stid.eq(id));
		@SuppressWarnings("unchecked")
		List<Student> list = criteria.list();
		if (list.size()==1) {
			student  = list.get(0);
		}
		return student;
	}


	@SuppressWarnings("unchecked")
	public List<Student> findByQty() {
		List<Student> students = new ArrayList<Student>();
		Criteria criteria = getSession().createCriteria(Student.class);
		criteria.createAlias("courseQty", "qty");
		criteria.add(Restrictions.le("qty.qty", 2));
		students = criteria.addOrder(Order.desc("qty.qty")).list();
		return students;
	}

}
