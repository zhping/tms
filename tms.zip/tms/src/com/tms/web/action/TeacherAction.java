package com.tms.web.action;

import javax.annotation.Resource;

import org.aspectj.weaver.ast.Var;
import org.hibernate.hql.ast.tree.BooleanLiteralNode;
import org.springframework.stereotype.Controller;

import com.opensymphony.xwork2.ModelDriven;
import com.opensymphony.xwork2.util.ResolverUtil;
import com.opensymphony.xwork2.util.logging.LoggerFactory;
import com.tms.web.model.Account;
import com.tms.web.model.Teacher;
import com.tms.web.service.AccountService;
import com.tms.web.service.TeacherSevice;
import com.tms.web.util.Result;

@Controller
public class TeacherAction extends BaseAction {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Teacher teacher;
	private Account account;
//	public Teacher getModel(){
//		if (teacher ==null) {
//			this.teacher=new Teacher();
//		}
//		return teacher;
//	}
	
	@Resource
	private TeacherSevice teacherSevice;
	
	@Resource
	private AccountService accountService;
	
	public String getTeacherAccount() {
		int teacherId = teacher.getTeacherId();
		session = teacherSevice.getTeacherAccount(teacherId);
		return SUCCESS;
	}
	public String listTeacher(){
		try {
			
			session = teacherSevice.listTeacher(teacher);
		} catch (Exception e) {
			 e.printStackTrace();
			 return ERROR;
		}
		return SUCCESS;
	}
	public String addTeacher(){
		System.out.println("teacher:"+teacher);
		System.out.println("account:"+account);
		account.setRoleType(2);
		account.setRole("ROLE_USER");
		try {
			result = accountService.save(account);
			if (result.getStatus()==0) {
				System.out.println("1:"+account);
				String accountId = accountService.getAccountId(account);
				System.out.println(accountId);
				teacher.setAccountId(accountId);
				System.out.println("addTeacheraction:"+teacher);
				boolean isSuccess = teacherSevice.addTeacher(teacher);
				if(isSuccess){
					session.put("status", 0);
				}else {
					session.put("status", 1);				
				}
			}else{
				session.put("status", 1);
				session.put("error", "账号已存在");
			}
		} catch (Exception e) {
			e.printStackTrace();
			return ERROR;
		}
		System.out.println("success");
		return SUCCESS;
	}

	public void setTeacher(Teacher teacher) {
		this.teacher = teacher;
	}
	public Account getAccount() {
		return account;
	}
	public void setAccount(Account account) {
		this.account = account;
	}
	public Teacher getTeacher() {
		return teacher;
	}
	
	
	
}
