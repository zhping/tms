package com.tms.web.action;

import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.ServletResponseAware;
import org.apache.struts2.interceptor.SessionAware;
import org.apache.struts2.util.ServletContextAware;

import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.Preparable;
import com.tms.web.util.Result;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class BaseAction extends ActionSupport implements ServletContextAware,
		ServletResponseAware, ServletRequestAware, SessionAware,Preparable {
	private static final long serialVersionUID = 1L;
	protected Log logger = LogFactory.getLog(getClass());
 
	protected ServletContext servletContext;
	protected HttpServletRequest httpServletRequest;
	protected HttpServletResponse httpServletResponse;
	protected HttpSession httpSession;
	protected String basePath;
	protected Map<String, Object> session;
	
	public HttpServletRequest getHttpServletRequest() {
		return httpServletRequest;
	}

	public void setHttpServletRequest(HttpServletRequest httpServletRequest) {
		this.httpServletRequest = httpServletRequest;
	}

	public HttpServletResponse getHttpServletResponse() {
		return httpServletResponse;
	}

	public void setHttpServletResponse(HttpServletResponse httpServletResponse) {
		this.httpServletResponse = httpServletResponse;
	}

	public Result getResult() {
		return result;
	}

	public void setResult(Result result) {
		this.result = result;
	}

	public ServletContext getServletContext() {
		return servletContext;
	}

	public Map<String, Object> getSession() {
		return session;
	}

	public void setBasePath(String basePath) {
		this.basePath = basePath;
	}

	public Result result = new Result();
	public String getBasePath() {
		String path = this.httpServletRequest.getContextPath();
		this.basePath = (this.httpServletRequest.getScheme() + "://"
				+ this.httpServletRequest.getServerName() + ":"
				+ this.httpServletRequest.getServerPort() + path + "/");
		return this.basePath;
	}

	public void setServletContext(ServletContext context) {
		this.servletContext = context;
	}

	public void setServletResponse(HttpServletResponse response) {
		this.httpServletResponse = response;
	}

	public HttpServletRequest getServletRequest() {
		return this.httpServletRequest;
	}

	public void setSession(Map<String, Object> session) {
		this.session = session;
	}
	 
	public void setServletRequest(HttpServletRequest arg0) {
		this.httpServletRequest = arg0;
		 this.httpSession = arg0.getSession();
		
	}

	@Override
	public void prepare() throws Exception {
		// TODO Auto-generated method stub
		
	}

}