package com.tms.web.action;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;

import com.opensymphony.xwork2.ModelDriven;
import com.tms.web.model.Campus;
import com.tms.web.model.Parent;
import com.tms.web.model.Student;
import com.tms.web.service.ParentService;
import com.tms.web.service.StudentService;
import com.tms.web.util.Util;

@Controller
public class StudentActionB extends BaseAction{
 
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Student student;
	private Parent parent;
	
	@Resource
	private StudentService studentService;
	@Resource
	private ParentService parentService;

	public String modiStudentInfo(){
		try {
//			boolean modiParentInfo = parentService.modiParentInfo(parent);
			boolean modiStudentInfo = studentService.modiStudentInfo(student,parent);
			
			if (!modiStudentInfo) {
				 session.put("status", 0);
			}else {
				session.put("status", 1);
			}
		} catch (Exception e) {
			e.printStackTrace();
			return ERROR;
		}
		return SUCCESS;
	}
	public Student getStudent() {
		return student;
	}
	public void setStudent(Student student) {
		this.student = student;
	}
	public Parent getParent() {
		return parent;
	}
	public void setParent(Parent parent) {
		this.parent = parent;
	}
	
	
	
	

	
	
}
