package com.tms.web.action;

import javax.annotation.Resource;
import javax.imageio.ImageIO;

import oracle.net.aso.e;

import org.apache.commons.collections.map.HashedMap;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ResponseBody;

import com.opensymphony.xwork2.ActionSupport;
import com.tms.web.model.Account;
import com.tms.web.service.LoginService;
import com.tms.web.util.Result;

@Controller
public class LoginAction extends BaseAction {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Resource
	private LoginService loginService;

	private Account account;
	
	private String validation;
	
	public String login1() {
		String validateSession = httpSession.getAttribute("validateCode").toString();
		try {
			if (validateSession.equals(validation)) {
				if(account!=null){
					account =  loginService.login(account);
				}else{
					return "login";
				}
	
			}
		} catch (Exception e) {
			e.printStackTrace();
			httpServletRequest.setAttribute("error","登录失败!");
			return "login";
		}
		return "index";
	}

	public String login() {
			String validateSession = httpSession.getAttribute("validateCode").toString();
		try {
			if (validateSession.equals(validation)) {
				if(account!=null){
					String username = account.getUsername();
					String password = account.getPassword();
					result = loginService.checkLogin(username, password);
					System.out.println("action----------"+username+password);
				}
			/*if (result.getStatus() == 0) {
				getServletRequest().getSession().setAttribute("accountId",
						accountId);
			}*/
			}else {
				result.setStatus(3);
				result.setMsg("验证码错误");
			}
		} catch (Exception e) {
			e.printStackTrace();
			return ERROR;
		}
		return SUCCESS;
	}

	/**
	 * 验证码
	 * @return
	 */
	public String getValidate() {
		session = loginService.getValidate();
		result.setData(session.get("is"));
		httpSession.setAttribute("validateCode", session.get("validateCode"));
		System.out.println("validateCode:"+httpSession.getAttribute("validateCode"));
		return SUCCESS;
	}

	public String logout() {
		result = loginService.logout(account.getAccountId());
		if (result.getStatus() == 0) {
			getServletRequest().getSession().invalidate();
		}
		return SUCCESS;
	}

	public String toIndex(){
		try {
			System.out.println(account);
			if (account==null) {
				return SUCCESS;
			}
			Integer roleType =account.getRoleType();
			System.out.println("type:"+roleType);
			if (roleType==1) {
				return "admin";
			} 
			if (roleType==2){
				return "teacher";
			}
		} catch (Exception e) {
			e.printStackTrace();
			return ERROR;
		}
		return SUCCESS;
	}
	/*------------------------getter-----和-------setter------------------*/

	 

	public Result getResult() {
		return result;
	}

	public Account getAccount() {
		return account;
	}

	public void setAccount(Account account) {
		this.account = account;
	}

	public void setResult(Result result) {
		this.result = result;
	}

	public String getValidation() {
		return validation;
	}

	public void setValidation(String validation) {
		this.validation = validation;
	}
	

}
