package com.tms.web.action;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;

import com.opensymphony.xwork2.ModelDriven;
import com.tms.web.model.Timetable;
import com.tms.web.service.SystemService;

@Controller
public class TimetableAction extends BaseAction implements ModelDriven<Timetable>{

	private static final long serialVersionUID = 1L;

	@Resource
	private SystemService service;
	
	private Timetable timetable;
	 
	public void prepareModiTimetable(){
		 Integer id = Integer.parseInt(httpServletRequest.getParameter("id"));
		 System.out.println(id);
		 this.timetable = service.loadTimetable(id);
		 
	}
	public String modiTimetable(){
		try {
			System.out.println(timetable);
			boolean flag = service.modiTimetable(timetable);
			if(flag){
				return ERROR;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return ERROR;
		}
		return SUCCESS;
	}
	
	
	
	public String delTimetable(){
		try {
			System.out.println(timetable.getId());
			Integer id = timetable.getId();
			service.delTimetable(id);
		} catch (Exception e) {
			e.printStackTrace();
			return ERROR;
		}
		return SUCCESS;
	}
	public String getTimetables(){
		try {
			session = service.listTimeTable();
		} catch (Exception e) {
			e.printStackTrace();
			return ERROR;
		}
		return SUCCESS;
	}
	
	public String addTimetable(){
		service.addTimetable(timetable);
		return SUCCESS;
	}
	 
	public String getTimetable(){
		try {
			session = service.getTimetable(timetable.getId());
		} catch (Exception e) {
			e.printStackTrace();
			return ERROR;
		}
		return SUCCESS;
	}
	
	public Timetable getModel() {
		if(timetable==null){
			this.timetable=new Timetable();
		}
		return timetable;
	}


	public void setTimetable(Timetable timetable) {
		this.timetable = timetable;
	}
	
}
