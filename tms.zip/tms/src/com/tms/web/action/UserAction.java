package com.tms.web.action;

import javax.annotation.Resource;

import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;

import com.tms.web.model.Account;
import com.tms.web.service.UserService;
import com.tms.web.util.Result;
import com.tms.web.util.Util;

@Controller
public class UserAction extends BaseAction{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public Result result = new Result();
	private String accountId;
	
	private String password;
	private String newPassword;
	
	@Resource
	private UserService userService;
	
	public String getUser(){
		try {
			accountId = Util.getCurrentAccount().getAccountId();
			 
			Account a =(Account)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
			 accountId = a.getAccountId();
			session = userService.getUser(accountId);
			servletContext.setAttribute("userInfo", session);
			System.out.println("==================get===================");
			 
			System.out.println(session.get("user"));
			System.out.println("==================getover===================");
		} catch (Exception e) {
			 
			e.printStackTrace();
			return ERROR;
		}
		return SUCCESS;
		
		
	}
	public String modiPwd(){
		try {
			if (accountId!=null) {
				session  = userService.modiPwd(accountId,password,newPassword);
			}
		} catch (Exception e) {
			e.printStackTrace();
			return ERROR;
		}
		return SUCCESS;
	}
	
	
	public String getAccountId() {
		return accountId;
	}

	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getNewPassword() {
		return newPassword;
	}

	public void setNewPassword(String newPassword) {
		this.newPassword = newPassword;
	}

}
