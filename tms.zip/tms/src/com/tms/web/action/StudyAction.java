package com.tms.web.action;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;

import com.tms.web.model.Study;
import com.tms.web.service.CourseQtyService;
import com.tms.web.service.StudyService;

@Controller
public class StudyAction extends BaseAction {

	private String ids;
	private String code;
	private Timestamp date;
	private Integer courseId;
	private int studyId;
	private Integer campusId;
	@Resource
	private StudyService studyService;

	@Resource
	private CourseQtyService courseQtyService;
	
	public String delStudyItem(){
		try {
			boolean delStudyItem = studyService.delStudyItem(studyId);
			if (delStudyItem) {
				session.put("status", 0);
				
			}else {
				session.put("status", 1);
			}
		} catch (Exception e) {
			e.printStackTrace();
			return ERROR;
		}
		return SUCCESS;
	}
	
	public String checkStudyItems(){
		try {
			String[] stIds = ids.split(",");
			
			List<Integer> isSignIds = new ArrayList<Integer>();
			for (int i = 0; i < stIds.length; i++) {
				int id = Integer.parseInt(stIds[i]);
				Study study = new Study();
				study.setStudentId(id);
				study.setCode(code);
				study.setDate(date);
				study.setCourseId(courseId);
				//判断该study是否存在，存在则提示已经签到
				boolean isSign = studyService.isSign(study);
				if(isSign){
					isSignIds.add(id);
				}
			}
			session.put("isSignIds", isSignIds);
			
		} catch (Exception e) {
			e.printStackTrace();
			return ERROR;
		}
		return SUCCESS;
	}
	
	
	
	public String getStudyItems(){
		System.out.println("StudyAction:"+courseId);
		session = studyService.getStudyItems(code,date,courseId,campusId);
		return SUCCESS;
	}
	
	
	public String addStudyItem() {
		String[] stIds = ids.split(",");
		List<Study> studys = new ArrayList<Study>();
		
		List<Integer> isSignIds = new ArrayList<Integer>();
		
		try {
			for (int i = 0; i < stIds.length; i++) {
				int id = Integer.parseInt(stIds[i]);
				Study study = new Study();
				study.setStudentId(id);
				study.setCode(code);
				study.setDate(date);
				study.setCourseId(courseId);
				study.setCampusId(campusId);
				//判断该study是否存在，存在则提示已经签到
				boolean isSign = studyService.isSign(study);
				if(!isSign){
					studys.add(study);
					courseQtyService.updateQty(1, id, false);//更新该学员的剩余课时量
				}else{
					isSignIds.add(id);
				}
				
			}
			session = studyService.addStudyItems(studys);
			session.put("isSignIds", isSignIds);
		} catch (Exception e) {
			e.printStackTrace();
			return ERROR;
		}
		return SUCCESS;
	}

	public String getIds() {
		return ids;
	}
	
	public void setIds(String ids) {
		this.ids = ids;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public Timestamp getDate() {
		return date;
	}

	public void setDate(Timestamp date) {
		this.date = date;
	}


	public Integer getCourseId() {
		return courseId;
	}


	public void setCourseId(Integer courseId) {
		this.courseId = courseId;
	}

	public int getStudyId() {
		return studyId;
	}

	public void setStudyId(int studyId) {
		this.studyId = studyId;
	}

	public Integer getCampusId() {
		return campusId;
	}

	public void setCampusId(Integer campusId) {
		this.campusId = campusId;
	}

	
	

}
