package com.tms.web.action;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;

import com.opensymphony.xwork2.ModelDriven;
import com.tms.web.model.Course;
import com.tms.web.service.SystemService;
@Controller
public class CourseAction extends BaseAction implements ModelDriven<Course>{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Resource
	private SystemService service;
	
	private Course course;
	
	public void prepareModiCourse(){
		 Integer id = Integer.parseInt(httpServletRequest.getParameter("courseId"));
		 this.course = service.loadCourse(id);
		 
	}
	public String modiCourse(){
		try {
			System.out.println(course);
			boolean flag = service.modiCourse(course);
			if(flag){
				return ERROR;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return ERROR;
		}
		return SUCCESS;
	}
	
	public String delCourse(){
		try {
			System.out.println(course.getCourseId());
			Integer id = course.getCourseId();
			service.delCourse(id);
		} catch (Exception e) {
			e.printStackTrace();
			return ERROR;
		}
		return SUCCESS;
	}
	
	public String getCourses(){
		System.out.println("-----------");
		try {
			session = service.listCourse();
		} catch (Exception e) {
			e.printStackTrace();
			return ERROR;
		}
		return SUCCESS;
	}
	public String addCourse(){
		try {
			System.out.println(course);
			System.out.println(service==null);
			service.addCourse(course);
		} catch (Exception e) {
			e.printStackTrace();
			return ERROR;
		}
		return SUCCESS;
	}
	
	public String getCourse(){
		try {
			session  = service.getCourse(course.getCourseId());
		} catch (Exception e) {
			e.printStackTrace();
			return ERROR;
		}
		return SUCCESS;
	}
		
	 
	
	public Course getModel() {
		if(course==null){
			this.course=new Course();
		}
		return course;
	}

	public void setCourse(Course course) {
		this.course = course;
	}
	

}
