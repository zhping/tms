package com.tms.web.action;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;

import com.tms.web.service.StudentService;
import com.tms.web.service.SystemService;

@Controller
public class SystemAction  extends BaseAction{

	private String accountId;
	
	@Resource
	private SystemService systemService;
	 
	public void getSystemInfos(){
		
		System.out.println("getSystemInfos:");
		session = systemService.getSystemInfos(accountId);
		servletContext.setAttribute("courses", session.get("courses"));
		servletContext.setAttribute("campuses", session.get("campuses"));
		servletContext.setAttribute("timetables", session.get("timetables"));
		servletContext.setAttribute("students", session.get("students"));
		/*
		return SUCCESS;*/
	}
	public String getAccountId() {
		return accountId;
	}
	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}
	
}
