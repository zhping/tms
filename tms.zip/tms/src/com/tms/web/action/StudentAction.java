package com.tms.web.action;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;

import com.opensymphony.xwork2.ModelDriven;
import com.tms.web.model.Parent;
import com.tms.web.model.Student;
import com.tms.web.service.ParentService;
import com.tms.web.service.StudentService;
import com.tms.web.util.Util;

@Controller
public class StudentAction extends BaseAction {
 
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private int campusId;
	private int courseId;
	private String num;
	private String name;
	private String stNums;
	private Student student;
	private Parent parent;
	public Student getStudent() {
		return student;
	}

	public void setStudent(Student student) {
		this.student = student;
	}

	@Resource
	private StudentService studentService;
	@Resource
	private ParentService parentService;

	
	
	public String toStudentInfo(){
		session.put("studentId", student.getId());
		return  SUCCESS;
	}
	
	public String getStudentInfo(){
		try {
			System.out.println(student.getId());
			Integer id = student.getId();
			if(id!=null){
				Student s = studentService.getStudent(id);
				System.out.println(s);
				session.put("student", s);
			}
		} catch (Exception e) {
			e.printStackTrace();
			return ERROR;
		}
		return SUCCESS;
	}
	public void  prepareAddStudent() {
		this.parent=new Parent();
	}
	public String addStudent() {
		String parentName=httpServletRequest.getParameter("parent.parentName");
		try {
			boolean isSuccess = studentService.addStudent(student,parent);
			if (!isSuccess) {
				throw new Exception("学员信息持久化失败");
			} 
		} catch (Exception e) {
			 e.printStackTrace();
			 return ERROR;
		}
		return SUCCESS;
	}
	
	public String getStudents(){
	
		System.out.println(campusId+","+courseId+","+num+","+name);
		try {
			String qtyMin=httpServletRequest.getParameter("qtyMin"),
					qtyMax=httpServletRequest.getParameter("qtyMax");
			session.put("students", studentService.getStudents(campusId,courseId,num,name,qtyMin,qtyMax)) ;
			System.out.println("session:"+session.get("students").toString());
		} catch (Exception e) {
			 
			e.printStackTrace();
			return ERROR;
		}
		return SUCCESS;
	}
	
	public String getSignStudents(){
		System.out.println("stNums:"+stNums);
		String[] nums = stNums.split(",");
		try {
			if(nums!=null){
				session = studentService.getSignStudents(nums);
				
			}else{
				session.put("error","未选择任何内容");
			}
		} catch (Exception e) {
			e.printStackTrace();
			return ERROR;
		}
		System.out.println(session.get("students"));
		System.out.println("action结束");
		return SUCCESS;
	}

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	public Parent getParent() {
		this.parent = new Parent();
		return parent;
	}

	public void setParent(Parent parent) {
		this.parent = parent;
	}

	public int getCampusId() {
		return campusId;
	}

	public void setCampusId(int campusId) {
		this.campusId = campusId;
	}

	public int getCourseId() {
		return courseId;
	}

	public void setCourseId(int courseId) {
		this.courseId = courseId;
	}

	public String getNum() {
		return num;
	}

	public void setNum(String num) {
		this.num = num;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	public String getStNums() {
		return stNums;
	}

	public void setStNums(String stNums) {
		this.stNums = stNums;
	}

/*	@Override
	public Student getModel() {
		this.student = new Student();
		return student;
	}*/
	public void setParentTel(String parentTel) {
		parent.setParentTel(parentTel);
	}
	public void setParentName(String parentName) {
		parent.setParentName(parentName);
	}

}
