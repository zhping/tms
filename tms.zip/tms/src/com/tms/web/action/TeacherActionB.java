package com.tms.web.action;

import javax.annotation.Resource;
import javax.persistence.criteria.CriteriaBuilder.In;

import org.apache.struts2.components.Password;
import org.aspectj.weaver.ast.Var;
import org.hibernate.hql.ast.tree.BooleanLiteralNode;
import org.springframework.stereotype.Controller;

import com.opensymphony.xwork2.ModelDriven;
import com.opensymphony.xwork2.util.ResolverUtil;
import com.opensymphony.xwork2.util.logging.LoggerFactory;
import com.tms.web.dao.AccountDao;
import com.tms.web.model.Account;
import com.tms.web.model.Teacher;
import com.tms.web.service.AccountService;
import com.tms.web.service.TeacherSevice;
import com.tms.web.service.UserService;
import com.tms.web.util.Result;
import com.tms.web.util.Util;

@Controller
public class TeacherActionB extends BaseAction{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Teacher teacher;
	private Account account;
	public Teacher getModel(){
		if (teacher ==null) {
			this.teacher=new Teacher();
		}
		return teacher;
	}
	
	@Resource
	private TeacherSevice teacherSevice;
	
	@Resource
	private UserService userService;
	
	@Resource
	private AccountDao accountDao;
	
	/*public void prepareModiTeacher(){
		 
		Integer id = Integer.parseInt(httpServletRequest.getParameter("teacherId"));
		this.teacher = teacherSevice.loadTeacher(id);
	}*/
	public String modiTeacher() throws Exception{
		System.out.println("xiugaijiaoshi:=="+teacher);
		System.out.println("xiugaijiaoshi:=="+account);
		String id = teacher.getAccountId();
		Account a = accountDao.find(id);
		String  password = account.getPassword(); 
		if(password!=null&&!password.equals("")){
			password = Util.md5(password);
			a.setPassword(password);
		}
		
		a.setUsername(account.getUsername());
		boolean f = userService.modiAccount(a);
		if (!f) {
			session = teacherSevice.modiTeacher(teacher);
		}
		
		return SUCCESS;
	}
	
	
	public Teacher getTeacher() {
		return teacher;
	}
	public void setTeacher(Teacher teacher) {
		this.teacher = teacher;
	}
	public Account getAccount() {
		return account;
	}
	public void setAccount(Account account) {
		this.account = account;
	}
	
}
