package com.tms.web.action;

import javax.annotation.Resource;
import javax.annotation.security.RolesAllowed;

import org.springframework.stereotype.Controller;

import com.opensymphony.xwork2.ModelDriven;
import com.tms.web.model.Pay;
import com.tms.web.service.PayService;
@Controller
public class PayAction extends BaseAction implements ModelDriven<Pay>{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Pay pay;
	@Resource
	private PayService payService;
	
//	@RolesAllowed("ROLE_ADMIN")
	public String addPay(){
		try {
			System.out.println("pay:"+pay);
			System.out.println(payService==null);
			session = payService.addPay(pay);
		} catch (Exception e) {
			e.printStackTrace();
			return ERROR;
		}
		return SUCCESS;
	}
	


	public void setPay(Pay pay) {
		this.pay = pay;
	}

	@Override
	public Pay getModel() {
		if (this.pay==null) {
			this.pay=new Pay();
		}
		return pay;
	}

}

