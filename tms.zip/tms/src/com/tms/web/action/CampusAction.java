package com.tms.web.action;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.spi.LoggerFactory;
import org.springframework.stereotype.Controller;

import com.opensymphony.xwork2.ModelDriven;
import com.opensymphony.xwork2.Preparable;
import com.tms.web.model.Campus;
import com.tms.web.service.SystemService;

@Controller
public class CampusAction extends BaseAction implements ModelDriven<Campus>{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Resource
	private SystemService service;
	private Campus campus;
	 
	public void prepareModiCampus(){
		 Integer id = Integer.parseInt(httpServletRequest.getParameter("campusId"));
		 this.campus = service.loadEntity(id);
		 
	}
	public String modiCampus(){
		try {
			System.out.println(campus);
			boolean flag = service.modiCampus(campus);
			if(flag){
				return ERROR;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return ERROR;
		}
		return SUCCESS;
	}
	public String delCampus(){
		try {
		
			System.out.println(campus.getCampusId());
			Integer id = campus.getCampusId();
			service.delCampus(id);
		} catch (Exception e) {
			e.printStackTrace();
			return ERROR;
		}
		return SUCCESS;
	}
	
	public String getCampuses(){
		try {
			System.out.println(campus);
			session = service.listCampus();
		} catch (Exception e) {
			e.printStackTrace();
			return ERROR;
		}
		return SUCCESS;
	}
	
	public String addCampus(){
		service.addCampus(campus);
		return SUCCESS;
	}
	 
	public String getCampus(){
		System.out.println("get");
		try {
			session = service.getCampus(campus.getCampusId());
		} catch (Exception e) {
			e.printStackTrace();
			return ERROR;
		}
		return SUCCESS;
	}
	
	public Campus getModel() {
		if(campus==null){
			this.campus=new Campus();
		}
		return campus;
	}

	public void setCampus(Campus campus) {
		this.campus = campus;
	}
	/*@Override
	public void prepare() throws Exception {
		HttpServletRequest request=getHttpServletRequest();
		Integer idInteger= Integer.parseInt(request.getParameter("campusId"));
		this.campus=service.loadEntity(idInteger);
		
	}*/
	
}
