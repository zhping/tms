var student;
function loadStudent(){
	var studentId = $("#student").val();
	$.ajax({
		url:"/student/get_student_info",
		type:"post",
		data:{"student.id":studentId},
		dataType:"json",
		success:function(result){
			student =result;
//			getInfo();
		},
		error:function(){
			dlg("error");
		}
	});
}
$(function(){
	loadStudent();
	$("#li-info").click();
	$("#modi-student").click(function(){
		if(confirm("确认修改学员信息？")){
			var id = $("#studentid").val();
			var num = $("#num").val();
			var name = $("#name").val();
			var gender = $("#gender").val();
			var bornDate = $("#date").val();
			var parentId = $("#parentId").val();
			var parentName = $("#parentName").val();
			var parentTel = $("#tel").val();
			var classInfo = $("#classInfo").val();
			var school = $("#school").val();
			var grade = $("#grade").val();
			var courseId = $("#courseId").val();
			var campusId = $("#campusId").val();
			$.post("/student/modi_student_info",
					{
					"student.id":id,
					"student.num":num,
					"student.name":name,
					"student.gender":gender,
					"student.bornDate":bornDate,
					"parent.parentId":parentId,
					"parent.parentName":parentName,
					"parent.parentTel":parentTel,
					"student.grade":grade,
					"student.classInfo":classInfo,
					"student.school":school,
					"student.courseId":courseId,
					"student.campusId":campusId},
					function(data){
						if(data==0){
							dlg("修改成功");
						}else{
							dlg("修改失败");
						}
					});
		}
		
	});
	
	
	$("#close-student").click(function(){
		$(".base").addClass("hide");
	});
	$("#add-pay").click(function(){
		$(".base").addClass("hide");
		$("#stId").val(student.id);
		$("#stNum").val(student.num);
		$("#stName").val(student.name);
		$("#csName").val(student.course.courseName);
		$("#add-pay-form").removeClass("hide");
	});
	$("#save-pay").click(function(){
		var stId = $("#stId").val();
		var money = $("#money").val();
		var addQty = $("#add_qty").val();
		var date = $("#pay_date").val();
		var csId = student.courseId;
		
		$.ajax({
			url:"/pay/add_pay_item",
			type:"post",
			data:{
				"studentId":stId,
				"courseId":csId,
				"money":money,
				"addQty":addQty,
				"date":date,
			},
			dataType:"json",
			success:function(){
				dlg("添加交费记录成功");
				$("#clear").click();
			},
			error:function(){
				dlg("添加交费记录失败");
			}
		
		});
	});
});

function getInfo(){
//	dlg(student.id);
	loadStudent();
	changeClass("li-info");
	$(".base").addClass("hide");
	$("#studentid").val(student.id);
	$("#num").val(student.num);
	$("#name").val(student.name);
	$("#gender").val(student.gender);
	$("#date").val(student.bornDate);
	$("#parentId").val(student.parents[0].parentId);
	$("#parentName").val(student.parents[0].parentName);
	$("#tel").val(student.parents[0].parentTel);
	$("#classInfo").val(student.classInfo);
	$("#school").val(student.school);
	$("#grade").val(student.grade);
	$("#courseId").val(student.courseId);
	$("#campusId").val(student.campusId);
	$("#qty").val(student.courseQty.qty);
	
	
	$(".info").removeClass("hide");
	
}

function getStudy(){
	loadStudent();
//	dlg(student.id);
	changeClass("li-study");
	$(".base").addClass("hide");
	var studys = student.studys;
//	dlg(studys.length);
	if(studys.length==0){
		dlg("没有上课记录");
	}else{
		$("#study-item tbody").empty();
		for(var i = 0;i<studys.length;i++){
			var study = studys[i];
			var tr='<tr>'
				 +'<td>'+study.id+'</td>'
				 +'<td>'+student.num+'</td>'
				 +'<td>'+student.name+'</td>'
				 +'<td>'+study.code+'</td>'
				 +'<td>'+study.date+'</td>'
				 +'<td>'+student.course.courseName+'</td>'
				 +'<td>'+student.campus.campusName+'</td>'
				 +'</tr>';
			$("#study-item tbody").append($(tr));
			$(".study-item").removeClass("hide");
		}
	}
	
	
}

function getPay(){
	loadStudent();
//	dlg(student.id);
	changeClass("li-pay");
	$(".base").addClass("hide");
	var pays = student.pays;
	var length = pays.length;
	if(length ==0 ){
		dlg("没有交费记录");
		$(".pay-item").removeClass("hide");
		$(".pay-form").addClass("hide");
	}else{
		$("#pay-item tbody").empty();
		for(var i =0;i<length;i++){
			var pay = pays[i];
			var tr='<tr>'
				 +'<td>'+pay.id+'</td>'
				 +'<td>'+pay.studentId+'</td>'
				 +'<td>'+student.name+'</td>'
				 +'<td>'+student.course.courseName+'</td>'
				 +'<td>'+pay.money+'</td>'
				 +'<td>'+pay.addQty+'</td>'
				 +'<td>'+pay.date+'</td>'
				 +'</tr>';
			$("#pay-item tbody").append($(tr));
			 
			$(".pay-item").removeClass("hide");
		}
	}
	
}

function changeClass(id){
	$("#ul-info li").removeClass("active");
	$("#"+id+"").addClass("active");
}