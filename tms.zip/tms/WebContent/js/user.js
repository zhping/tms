$(function(){
	/*$.post(
			"/user/to_get_user",
			{"accountId":accountId}
			);*/
	
	$("#modi_pwd").click(function(){
	
		$(".user-info").addClass("hide");
		$(".mod-pwd").removeClass("hide");
		$("#modPwd").click(function(){
			var accountId = $("#accountId").val();
			var pwd = $("#pwd").val();
			var npwd = $("#npwd").val();
			var rpwd = $("#rpwd").val();
			var reg_pwd = /^\w{6,20}$/;
			var flag = true;
			if(pwd==""){
				$("#pwd").addClass("error");
				 flag = false;
			}
			if(!reg_pwd.test(npwd)){
				 $("#npwd").addClass("error");
				 flag = false;
			}
			if(npwd!=rpwd){
				 $("#rpwd").addClass("error");
				 flag = false;
			}
			if(flag){
				$.ajax({
					url:"/user/to_modi_pwd",
					type:"post",
					data:{"accountId":accountId,
						"password":pwd,
						"newPassword":npwd},
					dataType:"json",
					success:function(data){
						
						dlg("密码修改成功");
						if(data.status==0){

							$("#cancel").click();
						}else if(data.status==1){
							$("#pwd").addClass("error");
						}
						
					},
					error:function(){
						dlg("通讯错误");
					}
				});
			}
		});
	});
});