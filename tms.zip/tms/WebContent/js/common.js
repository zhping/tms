function dlg(str){
	var s='<div id="dl" title="提示">'
			+'<p>'+str+'</p>'
			+'</div>';
	$("body").append(s);
	$("#dl").dialog({
	      autoOpen: true,
	      show: {
	        effect: "blind",
	        duration: 500
	      },
	      hide: {
	        effect: "slide",
	        duration: 1000
	      }
		
	    });
	 $("#dl").dialog("open");
	 setTimeout(function(){$("#dl").dialog("close");},2000);
}
