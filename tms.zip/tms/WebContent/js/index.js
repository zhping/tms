$(function(){
/*	$("#students_to_pay").dialog({
	      autoOpen: true,
	      show: {
	        effect: "blind",
	        duration: 500
	      },
	      hide: {
	        effect: "slide",
	        duration: 1000
	      }
		
	    });
	 $("#students_to_pay").dialog("open");
	 setTimeout(function(){$("#dl").dialog("close");},5000);*/
});