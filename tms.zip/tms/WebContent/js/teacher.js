
$(function(){
	
	$("#modify-teacher").click(function(){
		var id = $("#id2").val();
		var accountId = $("#accountId2").val();
		var code = $("#code2").val();
		var name = $("#name2").val(); 
		var username =$("#user2").val();
		var password = $("#pwd2").val();
		var tel = $("#tel2").val();
		var courseId = $("#course2").val();
		var campusId = $("#campus2").val();
		var status = $("#status2").val();
		var flag=true;
		var reg_name= /^[A-Za-z\u4E00-\u9FA5\uF900-\uFA2D]{1,20}$/;
		var reg_tel = /^1[0-9]{10}/;
		var reg_user = /^\w{2,30}$/;
		var reg_pwd = /^\w{6,20}$/;
		if(!reg_name.test(name)||name==""){
			$("#name2").addClass("error");
			flag=false;
		}
		if(!reg_tel.test(tel)){
			$("#tel2").addClass("error");
			flag=false;
		}
		if(!reg_user.test(username)|| username==""){
			$("#user2").addClass("error");
			flag=false;
		}
		/*if(!reg_pwd.test(password)|| password==""){
			$("#pwd2").addClass("error");
			flag=false;
		}*/
		if(flag){
			$.ajax({
				url:"/teacher/modi_teacher",
				type:"post",
				async:false,
				data:{
					"teacher.teacherId":id,
					"teacher.accountId":accountId,
					"teacher.teacherCode":code,
					"teacher.teacherName":name,
					"teacher.tel ":tel,
					"teacher.courseId":courseId,
					"teacher.campusId":campusId,
					"teacher.status":status,
					"account.username":username,
					"account.password":password
				},
				dataType:"json",
				success:function(data){
					dlg("修改成功:"+data); 
					
				},
				error:function(){
					dlg("通讯错误");
				}
			});
		}
		
	});
	
	
	
	
	
	
	
	/* 查詢教師列表*/
	$("#listTeacher").click(function(){
		$("#teacher-table tbody").empty();
		$(".base").addClass("hide");
		/*$(".content").load("/html/teacher_list.html");*/
		 var campusId = $("#campus").val();
		 var courseId = $("#course").val();
		 var status = $("#status").val();
		 var teacherName = $("#name").val().trim();
		 $.ajax({
			 url:"/teacher/list_teacher",
			 type:"post",
			/* async:false,*/
			 data:{
				 "teacher.campusId":campusId,
				 "teacher.courseId":courseId,
				 "teacher.status":status,
				 "teacher.teacherName":teacherName
			 },
			 dataType:"json",
			 success:function(teachers){
				/* dlg(teachers);
				 dlg("success");*/
				/* $(".content").load("/html/teacher_list.html");*/
				 $("#teacher-form").removeClass("hide");
				 for(var i=0;i<teachers.length;i++){
					 var tch = teachers[i];
					 var status="";
					 /*dlg("1");*/
					 if(tch.status==0){
						 status="在职";
					 }else{
						 status="离职";
					 }
					 var tr='<tr>'
						 +'<td>'+(i+1)+'</td>'
						 +'<td>'+tch.teacherCode+'</td>'
						 +'<td>'+tch.teacherName+'</td>'
						/* +'<td>'+tch.accountId+'</td>'*/
						 +'<td>'+tch.tel+'</td>'
						 +'<td>'+tch.course.courseName+'</td>'
						 +'<td>'+tch.campus.campusName+'</td>'
						 +'<td>'+status+'</td>'
						 +'<td><a href="javascript:modi('+tch.teacherId+')">修改</a></td>'
						 +'</tr>';
					 $("#teacher-table tbody").append($(tr));
					/* dlg("3");*/
				 }
				 
			 },
			 error:function(){
				 dlg("error");
			 }
		 
		 });
	});
	
	/*添加教师按钮点击事件 */
	$("#addTeacher").click(function(){
		/*dlg("add");*/
		$(".base").addClass("hide");
		$("#add-teacher").removeClass("hide");
		
        /*$(".content").load("/html/teacher_add.html");*/

	
	/*添加教师  保存按钮的点击事件 */
	$("#save-teacher").click(function(){
		/*dlg(22222);*/
		var name = $("#name1").val(); 
		var username =$("#user").val();
		var password = $("#pwd").val();
		var tel = $("#tel").val();
		var courseId = $("#course1").val();
		var campusId = $("#campus1").val();
		var status = $("#status1").val();
		var flag=true;
		var reg_name= /^[A-Za-z\u4E00-\u9FA5\uF900-\uFA2D]{1,20}$/;
		var reg_tel = /^1[0-9]{10}/;
		var reg_user = /^\w{2,30}$/;
		var reg_pwd = /^\w{6,20}$/;
		/*dlg(name+username+password);*/
		if(!reg_name.test(name)||name==""){
			$("#name1").addClass("error");
			flag=false;
		}
		if(!reg_tel.test(tel)){
			$("#tel").addClass("error");
			flag=false;
		}
		if(!reg_user.test(username)|| username==""){
			$("#user").addClass("error");
			flag=false;
		}
		if(!reg_pwd.test(password)|| password==""){
			$("#pwd").addClass("error");
			flag=false;
		}
		/*dlg(flag);*/
		if(flag){
			$.ajax({
				url:"/teacher/add_teacher",
				type:"post",
				async:false,
				data:{
					"teacher.teacherName":name,
					"teacher.tel ":tel,
					"teacher.courseId":courseId,
					"teacher.campusId":campusId,
					"teacher.status":status,
					"account.username":username,
					"account.password":password
				},
				dataType:"json",
				success:function(result){
					if(result.status==0){
						dlg("添加成功");
						$("#listTeacher").click();
					}else{
						dlg("添加失败"+result.error);
					}
					
				},
				error:function(){
					dlg("出错了");
				}
			});
		}
		
	});
	});
}); 
function getVal(str){
	return $("input[name="+str+"]").val();
}

function modi(tid){
	 
	$(".base").addClass("hide");
	$("#add-teacher").addClass("hide");
	$("#modi-teacher").removeClass("hide"); 
	$.ajax({
		url:"/teacher/get_teacher_account",
		type:"post",
		data:{"teacher.teacherId":tid},
		dataType:"json",
		success:function(data){
			var account = data.account;
			var t = data.teacher;
			$("#id2").val(t.teacherId); 
			$("#accountId2").val(t.accountId); 
			$("#code2").val(t.teacherCode); 
			$("#name2").val(t.teacherName); 
			$("#user2").val(account.username);
			 
			$("#tel2").val(t.tel);
			$("#course2").val(t.courseId);
			$("#campus2").val(t.campusId);
			$("#status2").val(t.status);
			 
		},
		error:function(){
			dlg("error");
		}
	});
	
}



