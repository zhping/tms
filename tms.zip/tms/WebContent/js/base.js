$(function(){
	var accountId = $("#userId").val();
	$.post("/system/get_system_items",{"accountId":accountId});
});

/**
 * 建立对话框，并在并闭时销毁
 * 参数options同easyui dialog之options
 * 增加自动居中
 * @param options
 * @returns
 */ 
function createDialog(options){
	var dlg=$("<div style='width:80;height:80;'></div>");
	dlg.appendTo($("body"));    
	var opt=$.extend({},options,{
		closed:false,				
		onOpen:(options.onOpen==null)?function(){
			$(dlg).dialog("center");
		}:options.onOpen,
		modal:(options.modal==null)?true:options.modal,
		onClose:function(){
	    	dlg.remove();
	    	if(options.onClose) $(options.onClose());
	    }
	});	
	dlg.dialog(opt);
	return dlg;
}