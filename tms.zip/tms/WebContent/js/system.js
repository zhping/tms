$(function(){
	$("#add-campus").click(function(){
		hideForm();
		$("#add-campus-form").removeClass("hide");
	});
		$("#save-campus").click(function(){
			 var campusName = $("#campusName").val();
			 var address = $("#address").val(); 
			 $(".clear-btn").click();
			 if(campusName!==""&&address!=""){
			 $.ajax({
				 url:"/system/add_campus",
				 type:"post",
				 data:{
					 "campusName":campusName,
					 "address":address
				 },
				 dataType:"json",
				 success:function(){
					 getCampuses();
				 },
				 error:function(){
					 dlg("error");
				 }
			 });
			 }
		});
	
	$("#add-course").click(function(){
		hideForm();
		$("#add-course-form").removeClass("hide");
	});
		$("#save-course").click(function(){
			var flag = true;
			var courseName = $("#courseName").val();
			var price = $("#price").val();
			var qty = $("#qty").val();
//			dlg(qty);
			var reg = /^\+?[1-9][0-9]*$/;
			if(!reg.test(qty)){
				dlg("请输入正确的数量");
				$("#qty").addClass("error");
				flag = false;
			};
			if(!reg.test(price)){
				dlg("请输入正确的价格");
				$("#price").addClass("error");
				flag = false;
			};
			if(flag){
				$(".clear-btn").click();
				$.ajax({
					 url:"/system/add_course",
					 type:"post",
					 data:{
						 "courseName":courseName,
						 "qty":qty,
						 "price":price
					 },
					 dataType:"json",
					 success:function(result){
						 getCourses();
					 },
					 error:function(){
						 dlg("error");
					 }
				});
			};
		});
	
	$("#add-timetable").click(function(){
		hideForm();
		$("#add-timetable-form").removeClass("hide");
	});
	
	$("#save-timetable").click(function(){
		var code =$("#code").val();
		var beginTime = $("#begin").val();
		var endTime = $("#end").val();
		var flag = true;
		if(code==""){
			flag = false;
			$("#code").addClass("error");
		}
		if(beginTime==""){
			flag = false;
			$("#begin").addClass("error");
		}
		if(endTime==""){
			flag = false;
			$("#end").addClass("error");
		}
		if(flag){
			$(".clear-btn").click();
			$.ajax({
				 url:"/system/add_timetable",
				 type:"post",
				 data:{
					 "code":code,
					 "beginTime":beginTime,
					 "endTime":endTime
				 },
				 dataType:"json",
				 success:function(result){
					 getTimetables();
				 },
				 error:function(){
					 dlg("error");
				 }
			});
		}
		 
	});
	
	$("#modi_campus").click(function(){
		var campusId = $("#cpId").val();
		var campusName = $("#cpName").val();
		var address = $("#cpAddress").val();
		var flag = true;
		if(campusName==""){
			flag = false;
			$("#cpName").addClass("error");
		}
		if(flag){
			$.ajax({
				url:"/system/modi_campus",
				type:"post",
				data:{
					"campusId":campusId,
					"campusName":campusName,
					"address":address
				},
				dataType:"json",
				success:function(data){
					dlg("success");
					getCampuses();
				},
				error:function(){
					dlg("error");
				}
			});
		}
	});
	
	
	$("#modi_course").click(function(){
		var courseId = $("#csId").val();
		var courseName = $("#csName").val();
		var price = $("#csPrice").val();
		var qty = $("#csQty").val();
		$.ajax({
			url:"/system/modi_course",
			type:"post",
			data:{
				"courseId":courseId,
				"courseName":courseName,
				"price":price,
				"qty":qty
			},
			dataType:"json",
			success:function(data){
				dlg("success");
			},
			error:function(){
				dlg("error");
			}
			
		});
	});
	
	
	$("#modi_timetable").click(function(){
		var id =$("#tid").val();
		var code = $("#tCode").val();
		var begin = $("#tBegin").val();
		var end = $("#tEnd").val();
		$.ajax({
			url:"/system/modi_timetable",
			type:"post",
			data:{
				"id":id,
				"code":code,
				"beginTime":begin,
				"end":end
			},
			dataType:"json",
			success:function(data){
				dlg("success");
			},
			error:function(){
				dlg("error");
			}
			
		});
	});
	
	
	
	
	
});

function getCampuses(){
	$("#campus-table tbody").empty();
	hideForm();
	 $("#campus-form").removeClass("hide");
	$.post("/system/get_campus_info",function(campuses){
		for(var i=0;i<campuses.length;i++){
			var c = campuses[i];
		 
			var tr='<tr>'
				 +'<td>'+c.campusId+'</td>'
				 +'<td>'+c.campusName+'</td>'
				 +'<td>'+c.address+'</td>'
				 +'<td><a href="javascript:modCampus('+c.campusId+')">修改</a></td>'
				 +'</tr>';
			 $("#campus-table tbody").append($(tr));
			 $("#campus-table").removeClass("hide");
		}
	});
}
function getCourses(){
//	dlg(2);
	$("#course-table tbody").empty();
	hideForm();
	 $("#course-form").removeClass("hide");
	$.post("/system/get_course_info",function(courses){
		for(var i=0;i<courses.length;i++){
//			dlg(courses.length+"-size");
			var c = courses[i];
			var tr='<tr>'
				 +'<td>'+c.courseId+'</td>'
				 +'<td>'+c.courseName+'</td>'
				 +'<td>'+c.price+'</td>'
				 +'<td>'+c.qty+'</td>'
				 +'<td><a href="javascript:modCourse('+c.courseId+')">修改</td>'
				 +'</tr>';
			 $("#course-table tbody").append($(tr));
			 $("#course-table").removeClass("hide");
			 
		}
	});
}
function getTimetables(){
	 $("#timetable-table tbody").empty();
	 hideForm();
	 $("#timetable-form").removeClass("hide");
	$.post("/system/get_timetable_info",function(timetables){
//		dlg(timetables.length);
		for(var i=0;i<timetables.length;i++){
			var t = timetables[i];
			var tr='<tr>'
				 +'<td>'+t.id+'</td>'
				 +'<td>'+t.code+'</td>'
				 +'<td>'+t.beginTime+'</td>'
				 +'<td>'+t.endTime+'</td>'
				 +'<td><a href="javascript:modTimetable('+t.id+')">修改</td>'
				 +'</tr>';
			 $("#timetable-table tbody").append($(tr));
			 $("#timetable-table").removeClass("hide");
			 
		}
	});
}

function hideForm(){
	 
	$(".add-form").addClass("hide");
	$(".list-form").addClass("hide");
	$(".modi").addClass("hide");
}

function delCampus(campusId){
	$.ajax({
		url:"/system/del_campus",
		type:"post",
		data:{"campusId":campusId},
		dataType:"json",
		success:function(data){
//			dlg(data);
			dlg("删除成功");
			getCampuses();
		},
		error:function(){
			dlg("error");
		}
	
	});
}
function delCourse(courseId){
	$.ajax({
		url:"/system/del_course",
		type:"post",
		data:{"courseId":courseId},
		dataType:"json",
		success:function(data){
//			dlg(data);
			dlg("删除成功");
			getCourses();
		},
		error:function(){
			dlg("error");
		}
	
	});
}
function delTimetable(id){
	$.ajax({
		url:"/system/del_timetable",
		type:"post",
		data:{"id":id},
		dataType:"json",
		success:function(data){
//			dlg(data);
			dlg("删除成功");
			getTimetables();
		},
		error:function(){
			dlg("error");
		}
	
	});
}
function modCampus(campusId){
	hideForm();
	$.ajax({
		url:"/system/get_campus",
		type:"post",
		data:{"campusId":campusId},
		dataType:"json",
		success:function(data){
			$("#cpId").val(data.campusId);
			$("#cpName").val(data.campusName);
			$("#cpAddress").val(data.address);
			$("#modify_campus").removeClass("hide");
		},
		error:function(){
			dlg("error");
		}
		
	});
}
function modCourse(courseId){
	hideForm();
	$.ajax({
		url:"/system/get_course",
		type:"post",
		data:{"courseId":courseId},
		dataType:"json",
		success:function(data){
			$("#csId").val(data.courseId);
			$("#csName").val(data.courseName);
			$("#csPrice").val(data.price);
			$("#csQty").val(data.qty);
			$("#modify_course").removeClass("hide");
		},
		error:function(){
			dlg("error");
		}
		
	});
}
function modTimetable(id){
	hideForm();
	$.ajax({
		url:"/system/get_timetable",
		type:"post",
		data:{"id":id},
		dataType:"json",
		success:function(data){
			$("#tid").val(data.id);
			$("#tCode").val(data.code);
			$("#tBegin").val(data.beginTime);
			$("#tEnd").val(data.endTime);
			$("#modify_timetable").removeClass("hide");
		},
		error:function(){
			dlg("error");
		}
		
	});
}