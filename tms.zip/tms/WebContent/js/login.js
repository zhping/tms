
/**
 * Created by Administrator on 2016/1/8.
 */
$(function(){
    
    $("#to_login").click(function(){
    	
        $("#username").removeClass("error");
        $("#password").removeClass("error");
        $("#validate").removeClass("error");
        $("#warning").text("");
        var flag=true;
        var username = $("#username").val().trim();
        var password = $("#password").val().trim();
        var validation = $("#validate").val().trim();
//        alert(username);
        if(username == ""){
           /* $("#warning").text("用户名不能为空");*/
            $("#username").addClass("error");
            flag=false;
        }
        if(password == ""){
           /* $("#warning").text("密码不能为空");*/
            $("#password").addClass("error");
            flag=false;
        }
        if(validation == ""){
            $("#validate").addClass("error");
            flag=false;
        }
        if(flag){
            /*发送请求*/
            $.ajax({
                url:"/login/to_login", 
                type:"post",
                data:{
                    "account.username":username,
                    "account.password":password,
                    "validation":validation
                },
                dataType:"json",
                success:function(result){
                	var status= result.status;
                    if(status==0){
                    	/*alert(result.data);*/
                    	 window.location.href="/home/to_index?account.accountId="+result.data.accountId+"&account.roleType="+result.data.roleType;
                    }
                    if(status==1){
                    	 $("#username").addClass("error");
                    	 $("#vali").click();
                    }
                    if(status==2){
                    	$("#password").addClass("error");
                    	$("#vali").click();
                    }
                    if(status==3){
                    	 $("#validate").addClass("error");
                    	 $("#vali").click();
                    }
                },
                error:function(){
                	alert(-1);
                }
            });
        }

    });

    /* 清空*/
    $(".clear img").mouseenter(function(){
        $(this).attr("src","../css/images/del-1.png");
    });
    $(".clear img").mouseleave(function(){
        $(this).attr("src","../css/images/del.png");
    });
    $(".clear img").click(function(){
        /*alert($(this).parent().next().val());*/
        $(this).parent().next().val("");
    });

});













































