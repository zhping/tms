/**
 * Created by Administrator on 2016/1/11.
 */

$(function(){
	
	$("#clear").click(function(){
		$(".sign-table tbody").empty();
		$(".study-table tbody").empty();
	});
    $("#cbox").click(function(){
        var flag =  document.getElementById("cbox").checked;

        var  checkbox=$(document.getElementsByName("cbox"));
        for(var i=0;i<checkbox.length;i++){
            checkbox[i].checked = flag;
        }
    });
    
    $("#box").click(function(){
        var flag =  document.getElementById("box").checked;
        var  checkbox=$(document.getElementsByName("box"));
        for(var i=0;i<checkbox.length;i++){
            checkbox[i].checked = flag;
        }
    });

    var item=1;
    $("#add").click(function (){  //jquery获取复选框值    
    	$(".base").addClass("hide");
    	var stNums = [];   
	    $('input[name="box"]:checked').each(function(){    
		    stNums.push($(this).val());    
	    });    
	    
	    if(stNums.length==0){
	    	dlg('请选择学员');
	    }else{
	    	var nums = stNums.toString();
	    	 $.ajax({
	    		 url:"/student/get_sign_students",
	    		 type:"post",
	    		 data:{"stNums":nums},
	    		 dataType:"json",
	    		 success:function(result){
	    			/*dlg(result.length);*/
	    			for(var i=0;i<result.length;i++){
	    				var student = result[i];
	    				var ids=[];
	    				$('input[name="id"]').each(function(){    
	    					ids.push($(this).val());    
	    				});
	    				 
	    				var id = student.id;
	    				var flag = $.inArray(id.toString(), ids);
	    				 
	    				if(flag==-1){
	    					var tr ='<tr>'
	    	    				+'<td><input type="checkbox" name="cbox" id="cb'+student.id+'" /><input style="display:none" value="'+student.campusId+'" /></td>'
	    	    				+'<td style="display:none"><input value="'+student.id+'" /><input value="'+student.courseId+'"/></td>'   
	    	    				+'<td>'+(item++)+'</td>'
	    	    				+'<td>'+student.num+'</td>'    
	    	    				+'<td>'+student.name+'</td>'    
	    	    				+'<td>'+student.course.courseName+'</td>' 
	    	    				+'<td>'+student.campus.campusName+'</td>'    
	    	    				+'<td>'+student.courseQty.qty+'</td>'    
	    	    				+'<td id="tda'+student.id+'" ><a href="javascript:toSign('+student.id+');">签到</a></td>'   
	    	    				+'</tr>'; 
	    	    			$(".sign-table tbody").append($(tr));
	    				}
	    				$("#sign-table").removeClass("hide");
	    			}  
	    		 },
	    		 error:function(){
	    			 dlg("error");
	    		 }
	    	 });
 	    }
	}); 
    
    /*签到  */
    $("#sign").click(function(){
    	 
    	var flag = true;
    	var flag2=true;
    	
    	var code = $("#timetable").val();
    	var date = $("#date").val();
    	var courseId = $("#cs").val();
    	var cpId=[]; 
    	var stIds=[];
    	$('input[name="cbox"]:checked').each(function(){    
    		 stIds.push($(this).parent().next().children().first().val());
    		 var csid = $(this).parent().next().children().last().val();
    		 var  campusId = $(this).next().val();
    		 cpId.push(campusId);
    		 if(csid!=courseId){
    			 flag2 = false;
    		 }
 	    });
    	cpId.sort();
    	var len = cpId.length;
    	
    	var campusId="";
    	var flag3=true;
    	if(cpId[0]==cpId[len-1]){
    		campusId = cpId[0];
    	}else{
    		flag3=false;
    	}
    	 
    	 if(code==""||date==""||courseId==""){
     		dlg("请选择签到内容");
     		flag = false;
     	}else if(stIds.length==0){
     		flag=false;
  	    	dlg('请选择学员');
     	}else if(!flag2){
     		dlg("请选择该科目的学员");
     	}else if(!flag3){
     		dlg("请确认校区");
     	}
    	  
    	if(flag&flag2&flag3){
 	    	var ids = stIds.toString();
 	    	sign(ids,code,date,courseId,campusId);
 	    }
    });
   $("#list-sign").click(function(){
	  $(".base").addClass("hide");
	  $(".sign-table tbody").empty();
	   var code = $("#timetable").val();
	   var date = $("#date").val();
	   var courseId = $("#cs").val();
	   var campusId = $("#campus").val();
	   var f = true;
	   if(f){
		   $.ajax({
			   url:"/study/get_study_items",
			   type:"post",
			   data:{
	    			"code":code,
	    			"date":date,
	    			"courseId":courseId,
	    			"campusId":campusId
			   },
			   dataType:"json",
			   success:function(data){
				  var studys = data.studys;
				  var students = data.students;
				  $(".study-table tbody").empty();
				  for(var i= 0;i<studys.length;i++){
					  var study = studys[i];
					  var stid=study.studentId;
					  var student = students[stid];
					  var tr ='<tr id="tr'+study.id+'">'
  	    				+'<td>'+(item++)+'</td>'
  	    				+'<td>'+student.num+'</td>'    
  	    				+'<td>'+student.name+'</td>' 
  	    				+'<td>'+study.code+'</td>'    
  	    				+'<td>'+study.date+'</td>' 
  	    				+'<td>'+student.course.courseName+'</td>' 
  	    				+'<td>'+student.campus.campusName+'</td>'    
  	    				+'<td>'+study.remainQty+'</td>'    
  	    				+'<td><a href="javascript:delSignItem('+study.id+')">删除</a></td>'   
  	    				+'</tr>'; 
					  $(".study-table tbody").append($(tr));
				  }
				  $("#study-table").removeClass("hide");
				  
			   },
			   error:function(){
				  dlg("查询签到记录失败"); 
			   }
		   });
	   }
   });
    
}); 

function sign(ids,code,date,courseId,campusId){
 
	//首先判断是否有学员已经签到
//	var f = true;//表示没有已经签到学员
	$.ajax({
			url:"/study/check_study_items",
			type:"post",
			data:{
 			"ids":ids,
 			"code":code,
 			"date":date,
 			"courseId":courseId
			},
			success:function(data){
	 			if(data!=""){
	    			for(var i =0;i<data.length;i++){
	    				var id =data[i];
	    				$("#cb"+id+"").attr("checked",false).attr("disabled",true);
	    				$("#tda"+id+"").empty();
	    				$("#tda"+id+"").text("已签到");
	    			}
	    			dlg("已签到学员不能重复签到");
		    		
	 			}else{
	 				$.ajax({
	 			 		url:"/study/add_study_items",
	 			 		type:"post",
	 			 		data:{
	 			 			"ids":ids,
	 			 			"code":code,
	 			 			"date":date,
	 			 			"courseId":courseId
	 			 		},
	 			 		dataType:"json",
	 			 		success:function(result){
	 				    		dlg("签到成功");
	 				    		var stIds = result.ids;
	 				    		
	 				    		if(stIds!=null){
	 				    			for(var i =0;i<stIds.length;i++){
	 				    				var id =stIds[i];
	 				    				$("#cb"+id+"").attr("checked",false).attr("disabled",true);
	 				    				$("#tda"+id+"").empty();
	 				    				$("#tda"+id+"").text("已签到");
	 				    			}
	 				    		}
	 				    		dlg("签到成功2");
	 			 		},
	 			 		error:function(){
	 			 			dlg("error");
	 			 		}
	 			 	});
	 			}
			}
		}
	);
	//没有学员签过到则可以进行签到
	 
		
 
	
}

function toSign(id){
	var stIds=[];
	stIds.push(id);
	var code = $("#timetable").val();
	var date = $("#date").val();
	var courseId = $("#cs").val();
	var flag = true;
	if(code==""||date==""||courseId==""){
		dlg("请选择签到内容");
		flag = false;
	}
	if(flag){
		var ids = stIds.toString();
		sign(ids,code,date,courseId);
	}
}



function delSignItem(studyId){
	var result = confirm("确定要删除该学员的本次签到？");
	if(result){
		$.post("/study/del_study_item",
				{"studyId":studyId},
				function(data){
					if(data.status==0){
						dlg("成功删除该条签到记录");
						$("#tr"+studyId+"").remove();
					}else{
						dlg("删除失败");
					}
				});
	}
}

