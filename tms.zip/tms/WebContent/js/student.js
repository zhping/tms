/**
 * Created by   on 2016/1/18.
 */

$(function(){
    
	$('#myModal').on('hidden.bs.modal', function () {
		var inputs=$("#strdentPanel input");
		for(var i=0;i<inputs.length;i++){
			$(inputs[i]).val("");
		}
		});

    
    $("#save-student").click(function(){
    	var name = $("#name1").val();
    	var gender = $("input[name='gender']:checked").val();
    	var date = $("#date").val();
    	var parentName = $("#parentName").val();
    	var tel = $("#tel").val();
    	var grade = $("#grade").val();
    	var classinfo = $("#class").val();
    	var school = $("#school").val();
    	var courseId = $("#courseId").val();
    	var campusId = $("#campusId").val();
    	
    	
    	
    	var reg_name= /^[A-Za-z\u4E00-\u9FA5\uF900-\uFA2D]{1,20}$/;
		var reg_tel = /^1[0-9]{10}/;
		var reg_grade = /^[0-9]{1,2}$/;
		
		var flag=true;
		if(!reg_name.test(name)||name==""){
			$("#name1").addClass("error");
			flag=false;
		}
		if(!reg_name.test(parentName)||parentName==""){
			$("#parentName").addClass("error");
			flag=false;
		}
		if(!reg_tel.test(tel)||tel==""){
			$("#tel").addClass("error");
			flag=false;
		}
		if(!reg_grade.test(grade)||grade==""){
			$("#grade").addClass("error");
			flag=false;
		}

//		dlg(flag);
//		dlg(parentName);
		if(flag){
			$.ajax({
				url:"/student/add_student",
				type:"post",
				data:{
					"student.name":name,
					"student.gender":gender,
					"student.bornDate":date,
					"parentName":parentName,
					"parentTel":tel,
					"student.grade":grade,
					"student.classInfo":classinfo,
					"student.school":school,
					"student.courseId":courseId,
					"student.campusId":campusId,
				},
				dataType:"json",
				success:function(){
					dlg("添加成功");
					$('#myModal').modal('hide');
					$("#listStudent").click();
				},
				error:function(){
					dlg("错误");
				}
			});
		}
		  
    });
    
    
    
    $("#listStudent").click(function(){
    	$("#student-table tbody").empty();
    	/*$("#student-form").removeClass("hide");*/
		$("#add-student").addClass("hide");
    	var campusId = $("#campus").val();
		var courseId = $("#course").val();
		var name = $("#name").val();
		var num = $("#stNum").val();
		var min=$("#qtyMin").val().trim(),
    	max=$("#qtyMax").val().trim(),
    	reg_qty=/\d+/g;
		if(!reg_qty.test(min)||!min){
			min="";
		}
		if(!reg_qty.test(max)||!max){
			max="";
		}
		$.ajax({
			 url:"/student/list_student",
			 type:"post",
			/* async:false,*/
			 data:{
				 "campusId":campusId,
				 "courseId":courseId,
				 "name":name,
				 "num":num,
				 qtyMin:min,
				 qtyMax:max
			 },
			 dataType:"json",
			 success:function(students){
				 if(students.length==0){
					 dlg("未查询到数据");
				 }else{
					 var data=[];
					 students.forEach(function(student,index){
						 var studentArray=[];
						 studentArray.push(index+1);
						 studentArray.push(student.num);
						 studentArray.push(student.name);
						 studentArray.push(student.parents[0].parentName);
						 studentArray.push(student.parents[0].parentTel);
						 studentArray.push(student.course.courseName);
						 studentArray.push(student.campus.campusName);
						 studentArray.push(student.courseQty.qty);
						 studentArray.push('<a href="/student/to_get_student_info?student.id='+student.id+'" >查看</a>');
						 data.push(studentArray);
					 });
					var table= $('#student-table').DataTable();
					table.clear().draw();
					table.rows.add(data).draw();
				 }
			 },
			 error:function(){
				 dlg("查询错误");
			}
		});
    });
});
